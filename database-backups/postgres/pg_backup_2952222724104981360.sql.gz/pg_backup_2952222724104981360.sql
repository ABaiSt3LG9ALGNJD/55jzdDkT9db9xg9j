-- =========================================================
-- PostgreSQL Database Dump (Pure JDBC Engine)
-- Dumped at: 2026-11-19T02:32:27.573239Z
-- =========================================================

-- ==========================================
-- SCHEMA: account
-- ==========================================
CREATE SCHEMA IF NOT EXISTS "account";

-- Table: account.account_service_roles
CREATE TABLE IF NOT EXISTS "account"."account_service_roles" (
    "id" bigserial NOT NULL,
    "account_id" int8 NOT NULL,
    "service_code" varchar(50) NOT NULL,
    "role" varchar(50) NOT NULL,
    "created_at" timestamptz,
    "updated_at" timestamptz
);

-- Table: account.accounts
CREATE TABLE IF NOT EXISTS "account"."accounts" (
    "id" bigserial NOT NULL,
    "username" varchar(50) NOT NULL,
    "email" varchar(100),
    "password" varchar(255) NOT NULL,
    "full_name" varchar(100),
    "is_super_admin" bool NOT NULL,
    "status" varchar(30) NOT NULL,
    "created_at" timestamptz,
    "updated_at" timestamptz
);
INSERT INTO "account"."accounts" ("id", "username", "email", "password", "full_name", "is_super_admin", "status", "created_at", "updated_at") VALUES ('1', 'superadmin', 'superadmin@system.local', 'SuperAdminSecret123!', 'System Super Administrator', 'true', 'ACTIVE', '2026-11-19 09:12:54.869787', '2026-11-19 09:12:54.869787') ON CONFLICT DO NOTHING;

-- Table: account.schema_migrations
CREATE TABLE IF NOT EXISTS "account"."schema_migrations" (
    "version" varchar NOT NULL
);
INSERT INTO "account"."schema_migrations" ("version") VALUES ('20261114000001') ON CONFLICT DO NOTHING;
INSERT INTO "account"."schema_migrations" ("version") VALUES ('20261112000001') ON CONFLICT DO NOTHING;
INSERT INTO "account"."schema_migrations" ("version") VALUES ('20261115000001') ON CONFLICT DO NOTHING;

-- Table: account.services
CREATE TABLE IF NOT EXISTS "account"."services" (
    "id" bigserial NOT NULL,
    "service_code" varchar(50) NOT NULL,
    "service_name" varchar(100) NOT NULL,
    "description" varchar(255),
    "status" varchar(30) NOT NULL,
    "created_at" timestamptz
);
INSERT INTO "account"."services" ("id", "service_code", "service_name", "description", "status", "created_at") VALUES ('1', 'GLOBAL_PORTAL', 'Cổng thông tin chung', 'Hệ thống portal dùng chung toàn hệ sinh thái', 'ACTIVE', '2026-11-19 09:12:54.869787') ON CONFLICT DO NOTHING;
INSERT INTO "account"."services" ("id", "service_code", "service_name", "description", "status", "created_at") VALUES ('2', 'VIDEOS_MANAGE', 'Hệ thống Quản lý Video', 'Hệ thống quản lý, biên tập và streaming video', 'ACTIVE', '2026-11-19 09:12:54.869787') ON CONFLICT DO NOTHING;
INSERT INTO "account"."services" ("id", "service_code", "service_name", "description", "status", "created_at") VALUES ('3', 'GITHUB_UPLOAD', 'Dịch vụ GitHub Upload', 'Dịch vụ lưu trữ file và repositories', 'ACTIVE', '2026-11-19 09:12:54.869787') ON CONFLICT DO NOTHING;

-- ==========================================
-- SCHEMA: github_upload
-- ==========================================
CREATE SCHEMA IF NOT EXISTS "github_upload";

-- Table: github_upload.organizations
CREATE TABLE IF NOT EXISTS "github_upload"."organizations" (
    "org" varchar(100) NOT NULL,
    "name" varchar(255),
    "description" text,
    "created_at" timestamptz
);
INSERT INTO "github_upload"."organizations" ("org", "name", "description", "created_at") VALUES ('ABaiSt3LG9ALGNJD', 'ABaiSt3LG9ALGNJD', 'Default initial organization', '2026-11-19 09:12:55.041438') ON CONFLICT DO NOTHING;

-- Table: github_upload.repositories
CREATE TABLE IF NOT EXISTS "github_upload"."repositories" (
    "id" bigserial NOT NULL,
    "org" varchar(100) NOT NULL,
    "repo_name" varchar(150) NOT NULL,
    "domain" varchar(255),
    "created_at" timestamptz
);
INSERT INTO "github_upload"."repositories" ("id", "org", "repo_name", "domain", "created_at") VALUES ('1', 'ABaiSt3LG9ALGNJD', 'jjjeJ4d8fsEc5M7g', 'https://cdn1.example.com', '2026-11-19 09:12:55.041438') ON CONFLICT DO NOTHING;
INSERT INTO "github_upload"."repositories" ("id", "org", "repo_name", "domain", "created_at") VALUES ('2', 'ABaiSt3LG9ALGNJD', '55jzdDkT9db9xg9j', 'https://cdn2.example.com', '2026-11-19 09:12:55.041438') ON CONFLICT DO NOTHING;
INSERT INTO "github_upload"."repositories" ("id", "org", "repo_name", "domain", "created_at") VALUES ('3', 'ABaiSt3LG9ALGNJD', 'y53tLKLziioPmapi', '', '2026-11-19 09:12:55.041438') ON CONFLICT DO NOTHING;

-- ==========================================
-- SCHEMA: public
-- ==========================================
CREATE SCHEMA IF NOT EXISTS "public";

-- ==========================================
-- SCHEMA: videos_manage
-- ==========================================
CREATE SCHEMA IF NOT EXISTS "videos_manage";

-- Table: videos_manage.category
CREATE TABLE IF NOT EXISTS "videos_manage"."category" (
    "category_id" varchar(150) NOT NULL,
    "name" varchar(600),
    "describe" text,
    "category_type_id" varchar(50),
    "date_create" timestamptz,
    "total_use" int4
);
INSERT INTO "videos_manage"."category" ("category_id", "name", "describe", "category_type_id", "date_create", "total_use") VALUES ('2', '2', '2', '2', '2026-11-19 09:15:28.218603', '0') ON CONFLICT DO NOTHING;

-- Table: videos_manage.category_type
CREATE TABLE IF NOT EXISTS "videos_manage"."category_type" (
    "category_type_id" varchar(150) NOT NULL,
    "name" varchar(600),
    "describe" text,
    "date_create" timestamptz
);

-- Table: videos_manage.category_with_video_sex_remote_gitlab
CREATE TABLE IF NOT EXISTS "videos_manage"."category_with_video_sex_remote_gitlab" (
    "category_id" varchar(150) NOT NULL,
    "video_id" varchar(150) NOT NULL,
    "date_create" timestamptz
);

-- Table: videos_manage.video_sex_remote_gitlab_db
CREATE TABLE IF NOT EXISTS "videos_manage"."video_sex_remote_gitlab_db" (
    "id" varchar(550) NOT NULL,
    "title" text,
    "describe" text,
    "m3u8_url" varchar(1000),
    "image_url" varchar(300),
    "date_create" timestamptz,
    "deploy" int2
);

-- Table: videos_manage.video_sex_remote_gitlab_db_video_url
CREATE TABLE IF NOT EXISTS "videos_manage"."video_sex_remote_gitlab_db_video_url" (
    "id" bigserial NOT NULL,
    "id_video" varchar(200) NOT NULL,
    "type_video_url" varchar(50) NOT NULL,
    "url_video" varchar(300),
    "extra_data" varchar(300),
    "create_date" timestamptz
);

-- Table: videos_manage.video_sex_xvideos_remote_gitlab_db
CREATE TABLE IF NOT EXISTS "videos_manage"."video_sex_xvideos_remote_gitlab_db" (
    "id" bigserial NOT NULL,
    "video_id" varchar(500),
    "title" text,
    "des" text,
    "xvideos_url" text,
    "xvideos_image_url" text,
    "m3u8_url_proxy" text,
    "image_url_proxy" text,
    "date_create" timestamptz,
    "deploy" int2
);

